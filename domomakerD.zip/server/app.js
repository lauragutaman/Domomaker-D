require('dotenv').config();
const path = require('path');
const express = require('express');
const compression = require('compression');
const favicon = require('serve-favicon');

const mongoose = require('mongoose');
const expressHandleBars = require('express-handlebars');
const helmet = require('helmet');
const session = require('express-session');

const router = require('./router.js');
const port = process.env.PORT || process.env.NODE_PORT || 3000;

const RedisStore = require('connect-redis').RedisStore;
const redis = require('redis');

const dbURI = process.env.MONGODB_URI || 'mongodb://localhost/Domomaker';
mongoose.connect(dbURI).catch((err) => {
    if (err) {
        console.log('Could not connect to database');
        throw err;

    }
});

const redisClient = redis.createClient({
    url: process.env.REDISCLOUD_URL,
});

redisClient.on('error', err => console.log('Redis Client Error', err));

redisClient.connect().then(() => {
    const app = express();
    app.use(helmet());
    app.use('/assets', express.static(path.resolve(`${__dirname}/../hosted`)));
    app.use(favicon(`${__dirname}/../hosted/img/favicon.png`));
    app.use(compression());
    app.use(express.urlencoded({ extended: true }));
    app.use(express.json());
    app.use(session({
        key: 'sessionID',
        store: new RedisStore({
            client: redisClient,
        }),
        secret: 'Domo Arigato',
        resave: false,
        saveUninitialized: false,
    }));

    app.engine('handlebars', expressHandleBars.engine({ defaultLayout: '' }));
    app.set('view engine', 'handlebars');
    app.set('views', `${__dirname}/../views`);

    router(app);

    app.listen(port, (err)=> {
        if(err) {throw err;}
        console.log(`Listening on port ${port}`);
    });

});




